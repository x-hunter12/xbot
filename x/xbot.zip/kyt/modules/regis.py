from kyt import *

@bot.on(events.NewMessage(pattern=r"(?:.regis|/regis)$"))
@bot.on(events.CallbackQuery(data=b'regis'))
async def menu(event):
	inline = [
[Button.inline(" ADD IP ","registrasi"),
Button.inline(" DELETE IP ","deleteip")],
[Button.inline(" ‹ Back Menu › ","menu")]]
	sender = await event.get_sender()
	val = valid(str(sender.id))
	if val == "false":
		try:
			await event.answer("Akses Ditolak", alert=True)
		except:
			await event.reply("Akses Ditolak")
	elif val == "true":
		sh = f' curl -sS https://raw.githubusercontent.com/zhets/izinsc/main/ip | grep "###" | wc -l'
		ssh = subprocess.check_output(sh, shell=True).decode("ascii")

		msg = f"""
━━━━━━━━━━━━━━━━━━━━━━━ 
**☘️ REGISTRASI IP AUTO SCRIPT☘️**
━━━━━━━━━━━━━━━━━━━━━━━ 
Hello {sender.first_name}
**Total User Script :** `{ssh.strip()}`
"""
		x = await event.edit(msg,buttons=inline)
		if not x:
			await event.reply(msg,buttons=inline)


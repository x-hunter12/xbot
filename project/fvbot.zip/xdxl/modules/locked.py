from xdxl import *

#CRATE VMESS
@bot.on(events.CallbackQuery(data=b'locked-bot'))
async def create_vmess(event):
	async def create_vmess_(event):
		cmd = 'bot-member-ssh'.strip()
		x = subprocess.check_output(cmd, shell=True, stderr=subprocess.STDOUT, universal_newlines=True)
		print(x)
		z = subprocess.check_output(cmd, shell=True).decode("utf-8")
		await event.respond(f"""
```
{z}
```
"""
		async with bot.conversation(chat) as user:
			await event.respond('**Username:**')
			user = user.wait_event(events.NewMessage(incoming=True, from_users=sender.id))
			user = (await user).raw_text
		cmd = f'printf "%s\n" egrep "{user}" /etc/passwd >/dev/null | passwd -l "{user}""'
		try:
			a = subprocess.check_output(cmd, shell=True).decode("utf-8")
		except:
			await event.respond("**User Already Exist**")
		else:
			msg = f"""
**━━━━━━━━━━━━━━━━━━━**
 **⟨ SUCCESS LOCKED SSH ⟩**
**━━━━━━━━━━━━━━━━━━━**
 `Username :` `{user}`
**━━━━━━━━━━━━━━━━━━━**
**» 🤖@xdxl_store**"""
			await event.respond(msg)
	chat = event.chat_id
	sender = await event.get_sender()
	a = valid(str(sender.id))
	if a == "true":
		await create_vmess_(event)
	else:
		await event.answer("Akses Ditolak",alert=True)